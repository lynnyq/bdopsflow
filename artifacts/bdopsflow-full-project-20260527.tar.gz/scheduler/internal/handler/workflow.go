package handler

import (
	"log/slog"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/lynnyq/bdopsflow/scheduler/internal/model"
	"github.com/lynnyq/bdopsflow/scheduler/internal/service"
)

type WorkflowHandler struct {
	svc *service.SchedulerService
}

func NewWorkflowHandler(svc *service.SchedulerService) *WorkflowHandler {
	return &WorkflowHandler{svc: svc}
}

func (h *WorkflowHandler) List(c *gin.Context) {
	ctx := c.Request.Context()

	defer func() {
		if r := recover(); r != nil {
			slog.Error("WorkflowHandler.List: panic recovered", "panic", r)
			Fail(c, CodeInternalError, "internal server error")
		}
	}()

	slog.Debug("WorkflowHandler.List: handling request")

	domainID, _ := c.Get("current_domain_id")
	userRole, _ := c.Get("role")

	var dID int64
	var role string
	if v, ok := domainID.(int64); ok {
		dID = v
	}
	if v, ok := userRole.(string); ok {
		role = v
	}

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "20"))

	bdopsflow_workflows, total, err := h.svc.ListWorkflows(ctx, dID, role, page, pageSize)
	if err != nil {
		slog.Error("WorkflowHandler.List: failed to list bdopsflow_workflows", "error", err)
		FailFromError(c, err)
		return
	}

	Success(c, gin.H{"items": bdopsflow_workflows, "total": total})
}

func (h *WorkflowHandler) Get(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		slog.Warn("WorkflowHandler.Get: invalid id", "id_str", idStr, "error", err)
		BadRequest(c, "invalid id")
		return
	}

	if id <= 0 {
		slog.Warn("WorkflowHandler.Get: id must be positive", "id", id)
		BadRequest(c, "id must be positive")
		return
	}

	ctx := c.Request.Context()
	wf, err := h.svc.GetWorkflow(ctx, id)
	if err != nil {
		slog.Error("WorkflowHandler.Get: failed to get workflow", "id", id, "error", err)
		NotFound(c, "workflow not found")
		return
	}

	Success(c, wf)
}

func (h *WorkflowHandler) Create(c *gin.Context) {
	var req struct {
		Name           string `json:"name"`
		Description    string `json:"description"`
		DomainID       int64  `json:"domain_id"`
		DAGConfig      string `json:"dag_config"`
		CronExpression string `json:"cron_expression"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		slog.Warn("WorkflowHandler.Create: invalid request body", "error", err)
		BadRequest(c, err.Error())
		return
	}

	if safeString(req.Name) == "" {
		slog.Warn("WorkflowHandler.Create: name is required")
		BadRequest(c, "name is required")
		return
	}

	if req.DomainID <= 0 {
		if jwtDomainID, ok := c.Get("current_domain_id"); ok {
			if v, typeOk := jwtDomainID.(int64); typeOk && v > 0 {
				req.DomainID = v
			}
		}
	}
	if req.DomainID <= 0 {
		req.DomainID = 1
	}

	now := time.Now()
	ctx := c.Request.Context()
	wf, err := h.svc.CreateWorkflow(ctx,
		`INSERT INTO bdopsflow_workflows (name, description, domain_id, dag_config, cron_expression, is_enabled, created_by, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?, 1, 1, ?, ?)`,
		safeString(req.Name), safeString(req.Description), req.DomainID,
		safeString(req.DAGConfig), safeString(req.CronExpression), now, now,
	)
	if err != nil {
		slog.Error("WorkflowHandler.Create: failed to create workflow", "name", req.Name, "error", err)
		FailFromError(c, err)
		return
	}

	slog.Info("WorkflowHandler.Create: workflow created", "workflow_id", wf.ID, "name", wf.Name)
	Created(c, wf)
}

func (h *WorkflowHandler) Update(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		slog.Warn("WorkflowHandler.Update: invalid id", "id_str", idStr, "error", err)
		BadRequest(c, "invalid id")
		return
	}

	if id <= 0 {
		slog.Warn("WorkflowHandler.Update: id must be positive", "id", id)
		BadRequest(c, "id must be positive")
		return
	}

	var wf model.Workflow
	if err := c.ShouldBindJSON(&wf); err != nil {
		slog.Warn("WorkflowHandler.Update: invalid request body", "error", err)
		BadRequest(c, err.Error())
		return
	}

	ctx := c.Request.Context()
	err = h.svc.UpdateWorkflow(ctx, id, &wf)
	if err != nil {
		slog.Error("WorkflowHandler.Update: failed to update workflow", "id", id, "error", err)
		FailFromError(c, err)
		return
	}

	wf.ID = id
	slog.Info("WorkflowHandler.Update: workflow updated", "id", id)
	Success(c, wf)
}

func (h *WorkflowHandler) Delete(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		slog.Warn("WorkflowHandler.Delete: invalid id", "id_str", idStr, "error", err)
		BadRequest(c, "invalid id")
		return
	}

	if id <= 0 {
		slog.Warn("WorkflowHandler.Delete: id must be positive", "id", id)
		BadRequest(c, "id must be positive")
		return
	}

	ctx := c.Request.Context()
	err = h.svc.DeleteWorkflow(ctx, id)
	if err != nil {
		slog.Error("WorkflowHandler.Delete: failed to delete workflow", "id", id, "error", err)
		FailFromError(c, err)
		return
	}

	slog.Info("WorkflowHandler.Delete: workflow deleted", "id", id)
	SuccessWithMessage(c, "deleted", nil)
}

func (h *WorkflowHandler) TriggerWorkflow(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		slog.Warn("WorkflowHandler.TriggerWorkflow: invalid id", "id_str", idStr, "error", err)
		BadRequest(c, "invalid id")
		return
	}

	if id <= 0 {
		slog.Warn("WorkflowHandler.TriggerWorkflow: id must be positive", "id", id)
		BadRequest(c, "id must be positive")
		return
	}

	ctx := c.Request.Context()
	we, err := h.svc.TriggerWorkflow(ctx, id)
	if err != nil {
		slog.Error("WorkflowHandler.TriggerWorkflow: failed to trigger workflow", "workflow_id", id, "error", err)
		FailFromError(c, err)
		return
	}

	slog.Info("WorkflowHandler.TriggerWorkflow: workflow triggered", "workflow_id", id, "execution_id", we.ExecutionID)
	Success(c, we)
}

func (h *WorkflowHandler) GetWorkflowExecutions(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		slog.Warn("WorkflowHandler.GetWorkflowExecutions: invalid id", "id_str", idStr, "error", err)
		BadRequest(c, "invalid id")
		return
	}

	if id <= 0 {
		slog.Warn("WorkflowHandler.GetWorkflowExecutions: id must be positive", "id", id)
		BadRequest(c, "id must be positive")
		return
	}

	ctx := c.Request.Context()
	executions, err := h.svc.ListWorkflowExecutions(ctx, id)
	if err != nil {
		slog.Error("WorkflowHandler.GetWorkflowExecutions: failed to list executions", "workflow_id", id, "error", err)
		FailFromError(c, err)
		return
	}

	Success(c, executions)
}

func (h *WorkflowHandler) GetWorkflowExecution(c *gin.Context) {
	executionID := c.Param("execution_id")
	if safeString(executionID) == "" {
		slog.Warn("WorkflowHandler.GetWorkflowExecution: executionId required")
		BadRequest(c, "executionId required")
		return
	}

	ctx := c.Request.Context()
	we, err := h.svc.GetWorkflowExecutionByExecutionID(ctx, executionID)
	if err != nil {
		slog.Error("WorkflowHandler.GetWorkflowExecution: failed to get workflow execution", "execution_id", executionID, "error", err)
		NotFound(c, "workflow execution not found")
		return
	}

	Success(c, we)
}

func (h *WorkflowHandler) GetExecutionLogs(c *gin.Context) {
	executionID := c.Param("execution_id")
	if safeString(executionID) == "" {
		slog.Warn("WorkflowHandler.GetExecutionLogs: executionId required")
		BadRequest(c, "executionId required")
		return
	}

	ctx := c.Request.Context()
	logs, err := h.svc.GetTaskLogsByExecutionID(ctx, executionID)
	if err != nil {
		slog.Error("WorkflowHandler.GetExecutionLogs: failed to get logs", "execution_id", executionID, "error", err)
		FailFromError(c, err)
		return
	}

	var response []*TaskLogResponse
	for _, log := range logs {
		response = append(response, toTaskLogResponse(log))
	}

	Success(c, response)
}
